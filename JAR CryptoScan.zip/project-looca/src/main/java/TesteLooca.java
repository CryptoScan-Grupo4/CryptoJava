
import Computador.Componente;
import Conexao.Conexao;
import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.sistema.Sistema;
import login.Funcionario;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;


public class TesteLooca {
    public static void main(String[] args) {
        Looca looca = new Looca();
        Conexao conexao = new Conexao();
        Sistema sistema = new Sistema();
        JdbcTemplate sql = conexao.getConexaoDoBanco();

        sql.execute("DROP TABLE IF EXISTS Computador.Componente");

        sql.execute("""
                CREATE TABLE Computador.Componente (
                idComponente INT PRIMARY KEY AUTO_INCREMENT,
                modeloComponente VARCHAR(45),
                tipoComponente VARCHAR(45),
                serialComponente VARCHAR(45)
                )
                """);

        sql.update("""
                INSERT INTO Computador.Componente (modeloComponente, tipoComponente, serialComponente) VALUES ('Intel I9' , 'Processador' , '457')
                """);

        List<Componente> componentesDoBanco = sql.query("SELECT * FROM Computador.Componente" ,
                new BeanPropertyRowMapper<>(Componente.class));
        System.out.println(componentesDoBanco);

        List<Funcionario> funcionariosDoBanco = sql.query("SELECT * FROM Funcionario" ,
                new BeanPropertyRowMapper<>(Funcionario.class));

        System.out.println(funcionariosDoBanco);


    }
}
